using GLAZOV.M.CONVERTER.Data;
using GLAZOV.M.CONVERTER.Errors;
using GLAZOV.M.CONVERTER.Settings;

namespace GLAZOV.M.CONVERTER.IO;

/// <summary>
/// Единая точка записи результата: файл, папка, поток или память. Пишется во временный файл (или в память)
/// и становится результатом только в <see cref="CommitAsync"/>; при ошибке и отмене временное удаляется.
/// </summary>
internal sealed class OutputSink : IAsyncDisposable
{
    private readonly Target _target;
    private readonly ConverterSettingsSnapshot _settings;
    private readonly string? _finalPath;
    private readonly string? _tempPath;
    private readonly bool _ownsStream;
    private bool _finished;

    private OutputSink(Target target, ConverterSettingsSnapshot settings, string? finalPath, string? tempPath, Stream stream, bool ownsStream)
    {
        _target = target;
        _settings = settings;
        _finalPath = finalPath;
        _tempPath = tempPath;
        Stream = stream;
        _ownsStream = ownsStream;
    }

    /// <summary>
    /// Поток, в который пишет движок.
    /// </summary>
    internal Stream Stream { get; }

    /// <summary>
    /// Умеет ли <see cref="Stream"/> перематываться (нужно форматам, которые правят заголовок после записи, например WAV).
    /// </summary>
    internal bool IsSeekable => Stream.CanSeek;

    /// <summary>
    /// Открывает приёмник. Существующий файл при <see cref="ConverterSettingsSnapshot.OverwriteExisting"/> = <c>false</c>
    /// отвергается сразу, до начала работы.
    /// </summary>
    /// <param name="target">Куда класть результат и в каком формате.</param>
    /// <param name="inputName">Имя входа — из него строится имя результата в папке.</param>
    /// <param name="settings">Настройки: перезапись, папка временных файлов.</param>
    /// <param name="requireSeekable">Нужен ли движку перематываемый вывод: для записываемого потока это даёт временный файл вместо канала.</param>
    /// <param name="cancellationToken">Отмена.</param>
    internal static ValueTask<OutputSink> OpenAsync(
        Target target,
        string inputName,
        ConverterSettingsSnapshot settings,
        bool requireSeekable = false,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(target);
        ArgumentException.ThrowIfNullOrWhiteSpace(inputName);
        ArgumentNullException.ThrowIfNull(settings);
        cancellationToken.ThrowIfCancellationRequested();

        return ValueTask.FromResult<OutputSink>(target.Kind switch
        {
            TargetKind.File => OpenFile(target, settings, target.Path!),
            TargetKind.Folder => GetFolderSink(target, settings, inputName),
            TargetKind.Memory => new(target, settings, null, null, new MemoryStream(), ownsStream: true),
            _ => OpenStream(target, settings, requireSeekable)
        });
    }

    /// <summary>
    /// Завершает запись: файл получает своё имя, память отдаёт байты и поток, чужой поток сбрасывается.
    /// </summary>
    /// <param name="cancellationToken">Отмена.</param>
    internal async ValueTask<SinkResult> CommitAsync(CancellationToken cancellationToken = default)
    {
        if (_finished)
        {
            throw new InvalidOperationException("Запись уже завершена или отменена.");
        }

        try
        {
            await Stream.FlushAsync(cancellationToken).ConfigureAwait(false);

            SinkResult result = _target.Kind switch
            {
                TargetKind.Memory => await CommitMemoryAsync().ConfigureAwait(false),
                TargetKind.Stream => await CommitStreamAsync(cancellationToken).ConfigureAwait(false),
                _ => await CommitFileAsync().ConfigureAwait(false),
            };

            _finished = true;
            return result;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException && ex is not ConversionException)
        {
            await AbortAsync().ConfigureAwait(false);
            throw Failures.OutputUnwritable(NameOfResult(), ex, ConversionStage.Conversion);
        }
        catch
        {
            await AbortAsync().ConfigureAwait(false);
            throw;
        }
    }

    private async ValueTask<SinkResult> CommitMemoryAsync()
    {
        byte[] bytes = ((MemoryStream)Stream).ToArray();
        await Stream.DisposeAsync().ConfigureAwait(false);
        return new SinkResult(null, bytes, new MemoryStream(bytes, writable: false));
    }

    // Чужой поток: если писали напрямую — только сбросили; если через временный файл — переливаем и удаляем его.
    private async ValueTask<SinkResult> CommitStreamAsync(CancellationToken cancellationToken)
    {
        if (_tempPath is not null)
        {
            Stream.Position = 0;
            await Stream.CopyToAsync(_target.OutputStream!, cancellationToken).ConfigureAwait(false);
            await _target.OutputStream!.FlushAsync(cancellationToken).ConfigureAwait(false);
            await Stream.DisposeAsync().ConfigureAwait(false);
            File.Delete(_tempPath);
        }

        return new SinkResult(null, null, null);
    }

    private async ValueTask<SinkResult> CommitFileAsync()
    {
        await Stream.DisposeAsync().ConfigureAwait(false);
        try
        {
            File.Move(_tempPath!, _finalPath!, overwrite: _settings.OverwriteExisting);
        }
        catch (IOException) when (!_settings.OverwriteExisting && File.Exists(_finalPath))
        {
            // Файл появился, пока шла работа: перезапись запрещена.
            throw Failures.FileExists(_finalPath!);
        }

        return new SinkResult(_finalPath, null, null);
    }

    /// <summary>
    /// Отменяет запись: недописанное удаляется, чужой поток не закрывается.
    /// </summary>
    internal async ValueTask AbortAsync()
    {
        if (_finished)
        {
            return;
        }

        _finished = true;
        if (_ownsStream)
        {
            await Stream.DisposeAsync().ConfigureAwait(false);
        }

        if (_tempPath is not null && File.Exists(_tempPath))
        {
            File.Delete(_tempPath);
        }
    }

    /// <inheritdoc />
    public ValueTask DisposeAsync()
    {
        return AbortAsync();
    }

    private string NameOfResult()
    {
        return _finalPath is not null ? Path.GetFileName(_finalPath) : "поток";
    }

    private static OutputSink OpenFile(Target target, ConverterSettingsSnapshot settings, string finalPath)
    {
        if (!settings.OverwriteExisting && File.Exists(finalPath))
        {
            throw Failures.FileExists(finalPath);
        }

        try
        {
            string directory = Path.GetDirectoryName(Path.GetFullPath(finalPath))!;
            Directory.CreateDirectory(directory);

            // Временный файл рядом с результатом: переименование внутри одной папки атомарно.
            string tempPath = Path.Combine(directory, $".{Path.GetFileName(finalPath)}.{Guid.NewGuid():N}.tmp");
            FileStream stream = new(tempPath, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None, 4096, FileOptions.Asynchronous);
            return new OutputSink(target, settings, finalPath, tempPath, new GuardedOutputStream(stream, Path.GetFileName(finalPath), ownsInner: true), ownsStream: true);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException)
        {
            throw Failures.OutputUnwritable(Path.GetFileName(finalPath), ex, ConversionStage.Preparation);
        }
    }

    private static OutputSink OpenStream(Target target, ConverterSettingsSnapshot settings, bool requireSeekable)
    {
        Stream output = target.OutputStream!;
        if (!output.CanWrite)
        {
            throw new ArgumentException("Поток результата не поддерживает запись.", nameof(target));
        }

        if (!requireSeekable)
        {
            return new OutputSink(target, settings, null, null, new GuardedOutputStream(output, "поток", ownsInner: false), ownsStream: false);
        }

        // Движку нужен перематываемый вывод, а чужой поток может его не дать: пишем во временный файл
        // и при завершении переливаем в поток.
        try
        {
            string directory = settings.TempFolder ?? Path.GetTempPath();
            Directory.CreateDirectory(directory);
            string tempPath = Path.Combine(directory, $"convert-{Guid.NewGuid():N}.tmp");
            FileStream temp = new(tempPath, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None, 4096, FileOptions.Asynchronous | FileOptions.DeleteOnClose);
            return new OutputSink(target, settings, null, tempPath, new GuardedOutputStream(temp, "поток", ownsInner: true), ownsStream: true);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException)
        {
            throw Failures.OutputUnwritable("поток", ex, ConversionStage.Preparation);
        }
    }

    private static OutputSink GetFolderSink(Target target, ConverterSettingsSnapshot settings, string inputName)
    {
        string fileName = Path.GetFileNameWithoutExtension(inputName);
        string extension = target.FileFormat.Extension;
        string fullPath = Path.Combine(target.Path!, $"{fileName}.{extension}");

        return OpenFile(target, settings, fullPath);
    }
}
