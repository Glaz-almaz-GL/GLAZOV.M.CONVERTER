using System.Diagnostics;
using GLAZOV.M.CONVERTER.Capabilities;
using GLAZOV.M.CONVERTER.Data;
using GLAZOV.M.CONVERTER.Detection;
using GLAZOV.M.CONVERTER.Engines;
using GLAZOV.M.CONVERTER.Errors;
using GLAZOV.M.CONVERTER.Execution;
using GLAZOV.M.CONVERTER.Extensions;
using GLAZOV.M.CONVERTER.IO;
using GLAZOV.M.CONVERTER.Settings;
using GLAZOV.M.CONVERTER.Tooling;

namespace GLAZOV.M.CONVERTER.Converting;

/// <summary>
/// Конвертация одного входа: открыть вход, подтвердить тип по начальным байтам, подобрать движок и программу,
/// открыть выход, выполнить, завершить запись. При ошибке и отмене временное удаляется, результат не остаётся.
/// </summary>
internal sealed class SingleConversion
{
    private readonly ConverterSettingsSnapshot _settings;
    private readonly EngineRegistry _registry;
    private readonly ToolLocator _locator;
    private readonly DetectorChain _chain;

    internal SingleConversion(ConverterSettingsSnapshot settings, EngineRegistry registry, ToolLocator locator, DetectorChain chain)
    {
        _settings = settings;
        _registry = registry;
        _locator = locator;
        _chain = chain;
    }

    /// <summary>
    /// Выполняет конвертацию. Папка во входе — неверное использование (<see cref="ArgumentException"/>).
    /// </summary>
    /// <param name="source">Файл или поток.</param>
    /// <param name="target">Файл, поток или память и формат результата.</param>
    /// <param name="options">Дополнительные параметры.</param>
    /// <param name="progress">Приёмник хода: 0 перед запуском движка и 100 после записи результата.</param>
    /// <param name="cancellationToken">Отмена.</param>
    internal async Task<ConversionResult> RunAsync(
        Source source,
        Target target,
        ConversionOptions? options,
        IProgress<ConversionProgress>? progress,
        CancellationToken cancellationToken)
    {
        if (source.Kind == SourceKind.Folder)
        {
            throw new ArgumentException("Папку нельзя конвертировать как один вход: для пакета используйте пакетную конвертацию.", nameof(source));
        }

        Stopwatch watch = Stopwatch.StartNew();
        await using InputHandle input = await InputReader.OpenAsync(source, cancellationToken).ConfigureAwait(false);

        FileFormat from = await ConfirmTypeAsync(input, cancellationToken).ConfigureAwait(false);
        ConversionOptions callOptions = options ?? new ConversionOptions();
        IConversionEngine engine = ChooseEngine(from, target.FileFormat, callOptions);
        (ToolStatus? tool, IReadOnlyDictionary<string, ToolStatus> tools) = LocateTools(engine);

        if (target.Kind == TargetKind.Folder && WritesSeveralFiles(engine, from, target.FileFormat))
        {
            return await RunSeveralFilesAsync(engine, input, from, target, callOptions, (tool, tools), progress, watch, cancellationToken).ConfigureAwait(false);
        }

        await using OutputSink sink = await OutputSink.OpenAsync(target, input.Name, _settings, cancellationToken: cancellationToken).ConfigureAwait(false);

        progress?.Report(new ConversionProgress(0));
        ProgressGate? gate = progress is null ? null : new ProgressGate(progress);
        ConversionRequest request = new(input.Stream, sink.Stream, from, target.FileFormat, callOptions, tool, _settings.TempFolder ?? Path.GetTempPath())
        {
            InputPath = input.Path,
            OnProgress = gate is null ? null : gate.Report,
            Tools = tools,
        };
        await RunEngineAsync(engine, request, cancellationToken).ConfigureAwait(false);
        SinkResult written = await sink.CommitAsync(cancellationToken).ConfigureAwait(false);
        progress?.Report(new ConversionProgress(100));

        watch.Stop();
        return new ConversionResult(true, from, target.FileFormat, watch.Elapsed, written.OutputPath, written.Bytes, written.Stream, request.Reencoded, notes: request.Notes);
    }

    // The engine writes the files into a staging folder; they reach the target folder together or not at all.
    private async Task<ConversionResult> RunSeveralFilesAsync(
        IConversionEngine engine,
        InputHandle input,
        FileFormat from,
        Target target,
        ConversionOptions callOptions,
        (ToolStatus? Tool, IReadOnlyDictionary<string, ToolStatus> Tools) located,
        IProgress<ConversionProgress>? progress,
        Stopwatch watch,
        CancellationToken cancellationToken)
    {
        using MultiFileOutput output = MultiFileOutput.Open(target.Path!, _settings);

        progress?.Report(new ConversionProgress(0));
        ProgressGate? gate = progress is null ? null : new ProgressGate(progress);
        ConversionRequest request = new(input.Stream, Stream.Null, from, target.FileFormat, callOptions, located.Tool, _settings.TempFolder ?? Path.GetTempPath())
        {
            InputPath = input.Path,
            OnProgress = gate is null ? null : gate.Report,
            Tools = located.Tools,
            OutputFolder = output.StagingFolder,
        };
        await RunEngineAsync(engine, request, cancellationToken).ConfigureAwait(false);
        cancellationToken.ThrowIfCancellationRequested();
        IReadOnlyList<string> paths = output.Commit(engine.GetType().Name);
        progress?.Report(new ConversionProgress(100));

        watch.Stop();
        return new ConversionResult(true, from, target.FileFormat, watch.Elapsed, paths[0], null, null, request.Reencoded, paths, request.Notes);
    }

    private static bool WritesSeveralFiles(IConversionEngine engine, FileFormat from, FileFormat to)
    {
        return engine.Pairs.Any(pair => pair.From.Equals(from) && pair.To.Equals(to) && pair.WritesSeveralFiles);
    }

    // Тип определяется по начальным байтам; имя файла — только подсказка для сообщения, доказательством не служит.
    private async Task<FileFormat> ConfirmTypeAsync(InputHandle input, CancellationToken cancellationToken)
    {
        FileFormat from = await InputDetection.DetectAsync(input, _chain, cancellationToken).ConfigureAwait(false);
        if (from.Equals(FileFormat.Unknown))
        {
            string extension = Path.GetExtension(input.Name).TrimStart('.').ToUpperInvariant();
            throw Failures.TypeNotConfirmed(input.Name, extension.Length == 0 ? null : extension, from);
        }

        return from;
    }

    private IConversionEngine ChooseEngine(FileFormat from, FileFormat to, ConversionOptions options)
    {
        IConversionEngine engine = _registry.Find(from, to) ?? throw Failures.UnsupportedConversion(from, to);
        if (options.Operations.Count > 0 && !engine.SupportsOperations)
        {
            throw Failures.UnsupportedOperations(from, to);
        }

        return engine;
    }

    // Программы нужны не каждому движку: расширение без внешней программы работает на своих библиотеках.
    // Обязательная и не найденная — отказ до запуска; необязательная передаётся как есть, с признаком «не найдена».
    private (ToolStatus? Tool, IReadOnlyDictionary<string, ToolStatus> Tools) LocateTools(IConversionEngine engine)
    {
        Dictionary<string, ToolStatus> tools = new(StringComparer.OrdinalIgnoreCase);
        ToolStatus? first = null;
        foreach (ToolSpec spec in engine.Tools)
        {
            ToolStatus status = _locator.Locate(spec, engine.Tools);
            if (spec.Required)
            {
                if (!status.Found)
                {
                    throw Failures.ToolNotFound(spec.Name, status.InstallHint);
                }

                first ??= status;
            }

            tools[spec.Name] = status;
        }

        return (first, tools);
    }

    // Любое непредвиденное исключение чужого движка становится ошибкой конвертации; свои ошибки и отмена проходят как есть.
    private static async Task RunEngineAsync(IConversionEngine engine, ConversionRequest request, CancellationToken cancellationToken)
    {
        try
        {
            await engine.ConvertAsync(request, cancellationToken).ConfigureAwait(false);
        }
        catch (Exception ex) when (ex is not (ConversionException or OperationCanceledException))
        {
            throw Failures.EngineFailed(engine.GetType().Name, ex);
        }
    }
}
